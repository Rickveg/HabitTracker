from Menu import Menu


def run():
    menu = Menu()

    menu.welcome()
    menu.run_main_menu()


if __name__ == '__main__':
    run()